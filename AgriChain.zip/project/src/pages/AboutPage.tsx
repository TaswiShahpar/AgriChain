import React from 'react';
import { 
  Shield, 
  BarChart3, 
  RefreshCw, 
  Zap,
  FileText,
  Users
} from 'lucide-react';

const AboutPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 pt-32 pb-16">
      <div className="max-w-4xl mx-auto">
        <div className="mb-12 text-center">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">About AgriChain</h1>
          <p className="text-xl text-gray-600">
            Revolutionizing agricultural supply chains with blockchain technology
          </p>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-8 mb-12">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Our Mission</h2>
          <p className="text-gray-600 mb-6">
            At AgriChain, we're on a mission to bring transparency, traceability, and trust to 
            the agricultural supply chain. By leveraging blockchain technology, we create an 
            immutable record of each product's journey from farm to table, ensuring consumers 
            know exactly where their food comes from and how it was handled.
          </p>
          
          <p className="text-gray-600">
            We believe that transparency in the food supply chain is not just a benefit—it's a 
            necessity. Our platform helps farmers showcase their sustainable practices, enables 
            distributors to verify product authenticity, and gives consumers confidence in their 
            purchasing decisions.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Why Blockchain?</h2>
            <div className="space-y-4">
              <FeatureItem 
                icon={<Shield className="w-6 h-6 text-green-600" />}
                title="Immutable Records"
                description="Once data is recorded on the blockchain, it cannot be altered, ensuring the integrity of product information."
              />
              
              <FeatureItem 
                icon={<BarChart3 className="w-6 h-6 text-green-600" />}
                title="Complete Traceability"
                description="Track every step of the product journey with timestamped, verifiable records."
              />
              
              <FeatureItem 
                icon={<RefreshCw className="w-6 h-6 text-green-600" />}
                title="Transparent Supply Chain"
                description="All participants can access the same information, creating trust between farmers, distributors, retailers, and consumers."
              />
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Benefits</h2>
            <div className="space-y-4">
              <FeatureItem 
                icon={<Zap className="w-6 h-6 text-green-600" />}
                title="Increased Efficiency"
                description="Streamline supply chain operations with real-time tracking and verification."
              />
              
              <FeatureItem 
                icon={<FileText className="w-6 h-6 text-green-600" />}
                title="Regulatory Compliance"
                description="Easily demonstrate compliance with food safety regulations through comprehensive documentation."
              />
              
              <FeatureItem 
                icon={<Users className="w-6 h-6 text-green-600" />}
                title="Consumer Trust"
                description="Build customer loyalty by providing verifiable information about product origins and handling."
              />
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">Our Team</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <TeamMember 
              name="Jane Doe"
              title="CEO & Founder"
              imageUrl="https://images.pexels.com/photos/1520760/pexels-photo-1520760.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=150"
            />
            
            <TeamMember 
              name="John Smith"
              title="CTO"
              imageUrl="https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=150"
            />
            
            <TeamMember 
              name="Emily Johnson"
              title="Agricultural Specialist"
              imageUrl="https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=150"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

interface FeatureItemProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const FeatureItem: React.FC<FeatureItemProps> = ({ icon, title, description }) => {
  return (
    <div className="flex">
      <div className="flex-shrink-0 mr-4">{icon}</div>
      <div>
        <h3 className="font-semibold text-gray-800 mb-1">{title}</h3>
        <p className="text-gray-600">{description}</p>
      </div>
    </div>
  );
};

interface TeamMemberProps {
  name: string;
  title: string;
  imageUrl: string;
}

const TeamMember: React.FC<TeamMemberProps> = ({ name, title, imageUrl }) => {
  return (
    <div className="text-center">
      <img 
        src={imageUrl} 
        alt={name}
        className="w-32 h-32 object-cover rounded-full mx-auto mb-4"
      />
      <h3 className="font-bold text-gray-800">{name}</h3>
      <p className="text-gray-600">{title}</p>
    </div>
  );
};

export default AboutPage;