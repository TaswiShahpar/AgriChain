import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Leaf, 
  BarChart3, 
  TrendingUp, 
  Shield, 
  Search, 
  RefreshCw 
} from 'lucide-react';
import { useBlockchain } from '../context/BlockchainContext';
import ProductList from '../components/Products/ProductList';

const HomePage: React.FC = () => {
  const { products, blockchain } = useBlockchain();
  
  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-green-600 to-green-800 pt-32 pb-24 md:pt-40 md:pb-32">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/440731/pexels-photo-440731.jpeg')] bg-cover bg-center opacity-20"></div>
        </div>
        <div className="container mx-auto px-4 relative">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6 animate-fadeIn">
              Transparent Agricultural Supply Chain
            </h1>
            <p className="text-xl text-green-100 mb-8 animate-fadeIn">
              Track farm products from harvest to consumer with blockchain technology. 
              Ensuring transparency, trust, and quality at every step.
            </p>
            <div className="flex flex-wrap gap-4 animate-fadeIn">
              <Link
                to="/products"
                className="bg-white text-green-700 hover:bg-green-50 font-medium px-6 py-3 rounded-lg transition-colors duration-300"
              >
                View Products
              </Link>
              <Link
                to="/verify"
                className="bg-transparent border-2 border-white text-white hover:bg-white hover:bg-opacity-10 font-medium px-6 py-3 rounded-lg transition-colors duration-300"
              >
                Verify Product
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      {/* Stats Section */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-green-50 p-6 rounded-lg text-center transform hover:scale-105 transition-transform duration-300">
              <BarChart3 className="w-10 h-10 text-green-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-gray-800 mb-2">
                {products.length}
              </h3>
              <p className="text-gray-600">Products Tracked</p>
            </div>
            
            <div className="bg-green-50 p-6 rounded-lg text-center transform hover:scale-105 transition-transform duration-300">
              <TrendingUp className="w-10 h-10 text-green-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-gray-800 mb-2">
                {blockchain.chain.length}
              </h3>
              <p className="text-gray-600">Blockchain Entries</p>
            </div>
            
            <div className="bg-green-50 p-6 rounded-lg text-center transform hover:scale-105 transition-transform duration-300">
              <Shield className="w-10 h-10 text-green-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-gray-800 mb-2">
                100%
              </h3>
              <p className="text-gray-600">Secure Transactions</p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">How It Works</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our blockchain solution provides end-to-end visibility of the agricultural supply chain
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <FeatureCard 
              icon={<Leaf className="w-10 h-10 text-green-600" />}
              title="Farm to Table"
              description="Track products from harvest through processing, distribution, and retail until they reach consumers."
            />
            
            <FeatureCard 
              icon={<Search className="w-10 h-10 text-green-600" />}
              title="Product Verification"
              description="Verify the authenticity and journey of agricultural products by scanning a simple QR code."
            />
            
            <FeatureCard 
              icon={<RefreshCw className="w-10 h-10 text-green-600" />}
              title="Real-time Updates"
              description="Every step in the supply chain is recorded on the blockchain in real-time, ensuring complete transparency."
            />
          </div>
        </div>
      </section>
      
      {/* Recent Products Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Recent Products</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Discover agricultural products currently being tracked in our system
            </p>
          </div>
          
          <ProductList />
        </div>
      </section>
    </div>
  );
};

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title, description }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md transition-transform duration-300 hover:-translate-y-1 hover:shadow-lg">
      <div className="bg-green-50 p-4 rounded-full inline-block mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-bold text-gray-800 mb-3">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

export default HomePage;