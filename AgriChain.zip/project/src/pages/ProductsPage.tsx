import React from 'react';
import ProductList from '../components/Products/ProductList';

const ProductsPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 pt-32 pb-16">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Products</h1>
        <p className="text-gray-600">
          Browse all agricultural products being tracked on our blockchain
        </p>
      </div>
      
      <ProductList />
    </div>
  );
};

export default ProductsPage;