import React, { useState } from 'react';
import { useBlockchain } from '../context/BlockchainContext';
import { Search, CheckCircle, AlertCircle } from 'lucide-react';
import BlockchainViewer from '../components/Blockchain/BlockchainViewer';

const VerifyPage: React.FC = () => {
  const { getProductById, getBlocksForProduct, validateChain } = useBlockchain();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResult, setSearchResult] = useState<{
    found: boolean;
    productId?: string;
  } | null>(null);
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!searchQuery.trim()) return;
    
    // In a real app, this would verify a QR code or product ID
    // For demo purposes, we'll just check if the product exists
    const foundProduct = getProductById(searchQuery);
    
    setSearchResult({
      found: !!foundProduct,
      productId: foundProduct?.id
    });
  };
  
  const isChainValid = validateChain();
  
  return (
    <div className="container mx-auto px-4 pt-32 pb-16">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-4">Verify Products</h1>
          <p className="text-gray-600">
            Enter a product ID or scan a QR code to verify its authenticity and trace its journey
          </p>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <form onSubmit={handleSearch} className="flex">
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Enter product ID"
              className="flex-grow px-4 py-2 border rounded-l-md focus:outline-none focus:ring-2 focus:ring-green-500"
            />
            <button
              type="submit"
              className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-r-md flex items-center transition-colors duration-300"
            >
              <Search className="w-5 h-5 mr-2" />
              Verify
            </button>
          </form>
        </div>
        
        {searchResult && (
          <div className={`bg-white rounded-lg shadow-md p-6 mb-8 ${
            searchResult.found ? 'border-l-4 border-green-500' : 'border-l-4 border-red-500'
          }`}>
            <div className="flex items-start">
              {searchResult.found ? (
                <CheckCircle className="w-6 h-6 text-green-500 mr-3 flex-shrink-0" />
              ) : (
                <AlertCircle className="w-6 h-6 text-red-500 mr-3 flex-shrink-0" />
              )}
              
              <div>
                <h3 className="text-lg font-semibold mb-2">
                  {searchResult.found ? 'Product Verified' : 'Product Not Found'}
                </h3>
                <p className="text-gray-600 mb-4">
                  {searchResult.found 
                    ? 'This product exists in our blockchain and has a valid history.'
                    : 'The product ID you entered was not found in our system. Please check the ID and try again.'}
                </p>
                
                {searchResult.found && searchResult.productId && (
                  <React.Fragment>
                    <BlockchainViewer blocks={getBlocksForProduct(searchResult.productId)} />
                  </React.Fragment>
                )}
              </div>
            </div>
          </div>
        )}
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-bold mb-4">Blockchain Status</h2>
          <div className="flex items-center mb-4">
            <div className={`w-4 h-4 rounded-full mr-2 ${isChainValid ? 'bg-green-500' : 'bg-red-500'}`}></div>
            <span className="font-medium">
              {isChainValid ? 'Blockchain verified and intact' : 'Blockchain integrity compromised'}
            </span>
          </div>
          <p className="text-gray-600">
            Our blockchain technology ensures that once data is recorded, it cannot be altered retroactively 
            without alteration of all subsequent blocks, which requires consensus of the network majority.
          </p>
        </div>
      </div>
    </div>
  );
};

export default VerifyPage;