import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useBlockchain } from '../context/BlockchainContext';
import { 
  ChevronLeft, 
  Wheat, 
  Package, 
  Box, 
  Truck, 
  ShoppingBag, 
  Home,
  Plus,
  Share,
  QrCode
} from 'lucide-react';
import { ProductStages } from '../models/Product';
import AddBlockForm from '../components/SupplyChain/AddBlockForm';
import SupplyChainTimeline from '../components/SupplyChain/SupplyChainTimeline';
import BlockchainViewer from '../components/Blockchain/BlockchainViewer';

const ProductDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getProductById, getBlocksForProduct } = useBlockchain();
  const [viewMode, setViewMode] = useState<'timeline' | 'blockchain'>('timeline');
  const [showAddBlock, setShowAddBlock] = useState(false);
  
  if (!id) {
    navigate('/products');
    return null;
  }
  
  const product = getProductById(id);
  const blocks = getBlocksForProduct(id);
  
  if (!product) {
    return (
      <div className="container mx-auto px-4 pt-32 pb-16">
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4">
          Product not found
        </div>
        <Link 
          to="/products"
          className="inline-flex items-center text-green-600 hover:text-green-700"
        >
          <ChevronLeft className="w-5 h-5 mr-1" /> Back to Products
        </Link>
      </div>
    );
  }
  
  const stageIcons = {
    [ProductStages.HARVEST]: <Wheat className="w-6 h-6" />,
    [ProductStages.PROCESSING]: <Package className="w-6 h-6" />,
    [ProductStages.PACKAGING]: <Box className="w-6 h-6" />,
    [ProductStages.DISTRIBUTION]: <Truck className="w-6 h-6" />,
    [ProductStages.RETAIL]: <ShoppingBag className="w-6 h-6" />,
    [ProductStages.CONSUMER]: <Home className="w-6 h-6" />
  };
  
  const stageTitles = {
    [ProductStages.HARVEST]: 'Harvested',
    [ProductStages.PROCESSING]: 'Processing',
    [ProductStages.PACKAGING]: 'Packaging',
    [ProductStages.DISTRIBUTION]: 'In Distribution',
    [ProductStages.RETAIL]: 'At Retail',
    [ProductStages.CONSUMER]: 'With Consumer'
  };
  
  const stageProgress = (() => {
    const stages = Object.values(ProductStages);
    const currentIndex = stages.indexOf(product.currentStage);
    return Math.round((currentIndex / (stages.length - 1)) * 100);
  })();
  
  return (
    <div className="container mx-auto px-4 pt-32 pb-16">
      <Link 
        to="/products"
        className="inline-flex items-center text-green-600 hover:text-green-700 mb-6"
      >
        <ChevronLeft className="w-5 h-5 mr-1" /> Back to Products
      </Link>
      
      <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
        <div className="grid grid-cols-1 md:grid-cols-3">
          <div className="h-64 md:h-auto md:col-span-1">
            <img 
              src={product.imageUrl || 'https://images.pexels.com/photos/5560867/pexels-photo-5560867.jpeg'} 
              alt={product.name}
              className="w-full h-full object-cover"
            />
          </div>
          
          <div className="p-6 md:col-span-2">
            <div className="flex justify-between items-start">
              <h1 className="text-3xl font-bold text-gray-800 mb-2">{product.name}</h1>
              <div className="flex space-x-2">
                <button className="text-gray-500 hover:text-gray-700 p-2 rounded-full hover:bg-gray-100 transition-colors duration-300">
                  <Share className="w-5 h-5" />
                </button>
                <button className="text-gray-500 hover:text-gray-700 p-2 rounded-full hover:bg-gray-100 transition-colors duration-300">
                  <QrCode className="w-5 h-5" />
                </button>
              </div>
            </div>
            
            <p className="text-gray-600 text-lg mb-4">
              {product.type} • {product.quantity} {product.unit}
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <p className="text-sm text-gray-500 mb-1">Farm</p>
                <p className="font-medium">{product.farmName}</p>
              </div>
              
              <div>
                <p className="text-sm text-gray-500 mb-1">Harvest Date</p>
                <p className="font-medium">{product.harvestDate}</p>
              </div>
              
              <div>
                <p className="text-sm text-gray-500 mb-1">Farmer ID</p>
                <p className="font-medium">{product.farmerId}</p>
              </div>
              
              <div>
                <p className="text-sm text-gray-500 mb-1">Current Stage</p>
                <div className="flex items-center">
                  <span className="inline-flex items-center bg-green-100 text-green-800 rounded-full py-1 px-3">
                    {stageIcons[product.currentStage as keyof typeof stageIcons]}
                    <span className="ml-1">{stageTitles[product.currentStage as keyof typeof stageTitles]}</span>
                  </span>
                </div>
              </div>
            </div>
            
            <div className="mb-4">
              <p className="text-sm text-gray-500 mb-1">Progress</p>
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div 
                  className="bg-green-600 h-2.5 rounded-full transition-all duration-1000"
                  style={{ width: `${stageProgress}%` }}
                ></div>
              </div>
            </div>
            
            {!product.isComplete && !showAddBlock && (
              <button
                onClick={() => setShowAddBlock(true)}
                className="inline-flex items-center bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-4 rounded-md transition-colors duration-300"
              >
                <Plus className="w-5 h-5 mr-2" />
                Add Next Stage
              </button>
            )}
          </div>
        </div>
      </div>
      
      {showAddBlock && (
        <div className="mb-8">
          <AddBlockForm 
            productId={product.id} 
            currentStage={product.currentStage}
            onSuccess={() => setShowAddBlock(false)}
          />
        </div>
      )}
      
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold text-gray-800">Supply Chain Journey</h2>
          <div className="flex rounded-lg overflow-hidden border border-gray-300">
            <button 
              onClick={() => setViewMode('timeline')}
              className={`py-2 px-4 text-sm font-medium ${
                viewMode === 'timeline' 
                  ? 'bg-green-600 text-white' 
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              Timeline
            </button>
            <button 
              onClick={() => setViewMode('blockchain')}
              className={`py-2 px-4 text-sm font-medium ${
                viewMode === 'blockchain' 
                  ? 'bg-green-600 text-white' 
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              Blockchain
            </button>
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-6">
        {viewMode === 'timeline' ? (
          <SupplyChainTimeline blocks={blocks} />
        ) : (
          <BlockchainViewer blocks={blocks} />
        )}
      </div>
    </div>
  );
};

export default ProductDetailPage;