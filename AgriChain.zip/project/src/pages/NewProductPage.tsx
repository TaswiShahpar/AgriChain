import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';
import ProductForm from '../components/Products/ProductForm';

const NewProductPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 pt-32 pb-16">
      <Link 
        to="/products"
        className="inline-flex items-center text-green-600 hover:text-green-700 mb-6"
      >
        <ChevronLeft className="w-5 h-5 mr-1" /> Back to Products
      </Link>
      
      <ProductForm />
    </div>
  );
};

export default NewProductPage;