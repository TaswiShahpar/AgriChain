export interface Product {
  id: string;
  name: string;
  type: string;
  quantity: number;
  unit: string;
  farmName: string;
  farmerId: string;
  harvestDate: string;
  imageUrl?: string;
  currentStage: string;
  isComplete: boolean;
}

export const ProductStages = {
  HARVEST: 'harvest',
  PROCESSING: 'processing',
  PACKAGING: 'packaging',
  DISTRIBUTION: 'distribution',
  RETAIL: 'retail',
  CONSUMER: 'consumer'
};