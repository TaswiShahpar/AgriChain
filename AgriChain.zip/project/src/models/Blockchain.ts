import { v4 as uuidv4 } from 'uuid';
import { Block, BlockData } from './Block';

export class Blockchain {
  chain: Block[];
  difficulty: number;

  constructor() {
    this.chain = [this.createGenesisBlock()];
    this.difficulty = 2;
  }

  createGenesisBlock(): Block {
    const genesisData: BlockData = {
      id: uuidv4(),
      productId: 'genesis',
      productName: 'Genesis Block',
      stage: 'genesis',
      location: 'System',
      timestamp: new Date().getTime(),
      actor: 'System',
      details: { message: 'Genesis Block' }
    };
    return new Block(genesisData, '0');
  }

  getLatestBlock(): Block {
    return this.chain[this.chain.length - 1];
  }

  addBlock(newBlockData: BlockData): Block {
    const previousBlock = this.getLatestBlock();
    const newBlock = new Block(newBlockData, previousBlock.hash);
    newBlock.mineBlock(this.difficulty);
    this.chain.push(newBlock);
    return newBlock;
  }

  isChainValid(): boolean {
    for (let i = 1; i < this.chain.length; i++) {
      const currentBlock = this.chain[i];
      const previousBlock = this.chain[i - 1];

      if (currentBlock.hash !== currentBlock.calculateHash()) {
        return false;
      }

      if (currentBlock.previousHash !== previousBlock.hash) {
        return false;
      }
    }
    return true;
  }

  getBlocksForProduct(productId: string): Block[] {
    return this.chain.filter(block => block.data.productId === productId);
  }
}