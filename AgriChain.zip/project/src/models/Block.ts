import SHA256 from 'crypto-js/sha256';

export interface BlockData {
  id: string;
  productId: string;
  productName: string;
  stage: string;
  location: string;
  timestamp: number;
  actor: string;
  details: Record<string, any>;
}

export class Block {
  hash: string;
  previousHash: string;
  data: BlockData;
  timestamp: number;
  nonce: number;

  constructor(data: BlockData, previousHash = '') {
    this.data = data;
    this.previousHash = previousHash;
    this.timestamp = new Date().getTime();
    this.nonce = 0;
    this.hash = this.calculateHash();
  }

  calculateHash(): string {
    return SHA256(
      this.previousHash +
        this.timestamp +
        JSON.stringify(this.data) +
        this.nonce
    ).toString();
  }

  mineBlock(difficulty: number): void {
    const target = Array(difficulty + 1).join('0');
    while (this.hash.substring(0, difficulty) !== target) {
      this.nonce++;
      this.hash = this.calculateHash();
    }
    console.log(`Block mined: ${this.hash}`);
  }
}