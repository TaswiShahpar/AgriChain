import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { Blockchain } from '../models/Blockchain';
import { Block, BlockData } from '../models/Block';
import { Product, ProductStages } from '../models/Product';

interface BlockchainContextType {
  blockchain: Blockchain;
  products: Product[];
  loading: boolean;
  addBlock: (data: Omit<BlockData, 'id' | 'timestamp'>) => Block;
  addProduct: (product: Omit<Product, 'id' | 'currentStage' | 'isComplete'>) => Product;
  getProductById: (id: string) => Product | undefined;
  getBlocksForProduct: (productId: string) => Block[];
  validateChain: () => boolean;
}

const BlockchainContext = createContext<BlockchainContextType | undefined>(undefined);

export const useBlockchain = () => {
  const context = useContext(BlockchainContext);
  if (!context) {
    throw new Error('useBlockchain must be used within a BlockchainProvider');
  }
  return context;
};

interface BlockchainProviderProps {
  children: ReactNode;
}

export const BlockchainProvider: React.FC<BlockchainProviderProps> = ({ children }) => {
  const [blockchain, setBlockchain] = useState<Blockchain>(new Blockchain());
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Initialize with demo data
  useEffect(() => {
    // In a real app, you would load from a persistence layer
    const demoProducts = [
      {
        id: uuidv4(),
        name: 'Organic Rice',
        type: 'Basmati',
        quantity: 100,
        unit: 'kg',
        farmName: 'Green Valley Farms',
        farmerId: 'farmer-001',
        harvestDate: '2025-05-15',
        imageUrl: 'https://images.pexels.com/photos/4389575/pexels-photo-4389575.jpeg',
        currentStage: ProductStages.HARVEST,
        isComplete: false
      },
      {
        id: uuidv4(),
        name: 'Fresh Wheat',
        type: 'Whole Grain',
        quantity: 200,
        unit: 'kg',
        farmName: 'Sunny Fields',
        farmerId: 'farmer-002',
        harvestDate: '2025-05-10',
        imageUrl: 'https://images.pexels.com/photos/326082/pexels-photo-326082.jpeg',
        currentStage: ProductStages.PACKAGING,
        isComplete: false
      }
    ];

    setProducts(demoProducts);
    
    // Add demo blocks for the demo products
    const newBlockchain = new Blockchain();
    
    // First product blocks
    newBlockchain.addBlock({
      id: uuidv4(),
      productId: demoProducts[0].id,
      productName: demoProducts[0].name,
      stage: ProductStages.HARVEST,
      location: 'Green Valley Farms, CA',
      timestamp: new Date().getTime() - 3 * 24 * 60 * 60 * 1000, // 3 days ago
      actor: 'John Farmer',
      details: {
        temperature: '25°C',
        humidity: '65%',
        notes: 'Excellent quality crop'
      }
    });
    
    // Second product blocks
    newBlockchain.addBlock({
      id: uuidv4(),
      productId: demoProducts[1].id,
      productName: demoProducts[1].name,
      stage: ProductStages.HARVEST,
      location: 'Sunny Fields, OR',
      timestamp: new Date().getTime() - 5 * 24 * 60 * 60 * 1000, // 5 days ago
      actor: 'Mary Farmer',
      details: {
        temperature: '22°C',
        humidity: '60%',
        notes: 'Harvested after light rain'
      }
    });
    
    newBlockchain.addBlock({
      id: uuidv4(),
      productId: demoProducts[1].id,
      productName: demoProducts[1].name,
      stage: ProductStages.PROCESSING,
      location: 'Mill Processing Center, WA',
      timestamp: new Date().getTime() - 3 * 24 * 60 * 60 * 1000, // 3 days ago
      actor: 'Processing Team',
      details: {
        moisture: '12%',
        qualityGrade: 'A',
        notes: 'Cleaned and sorted'
      }
    });
    
    newBlockchain.addBlock({
      id: uuidv4(),
      productId: demoProducts[1].id,
      productName: demoProducts[1].name,
      stage: ProductStages.PACKAGING,
      location: 'Packaging Facility, WA',
      timestamp: new Date().getTime() - 1 * 24 * 60 * 60 * 1000, // 1 day ago
      actor: 'Packaging Team',
      details: {
        packageType: 'Eco-friendly bags',
        weight: '1kg per package',
        batchNumber: 'B12345'
      }
    });
    
    setBlockchain(newBlockchain);
    setLoading(false);
  }, []);

  const addBlock = (data: Omit<BlockData, 'id' | 'timestamp'>) => {
    const blockData: BlockData = {
      ...data,
      id: uuidv4(),
      timestamp: new Date().getTime()
    };
    
    const newBlock = blockchain.addBlock(blockData);
    
    // Update product state
    setProducts(prevProducts => 
      prevProducts.map(product => {
        if (product.id === data.productId) {
          // Update the product's current stage
          const isComplete = data.stage === ProductStages.CONSUMER;
          return {
            ...product,
            currentStage: data.stage,
            isComplete
          };
        }
        return product;
      })
    );
    
    return newBlock;
  };

  const addProduct = (productData: Omit<Product, 'id' | 'currentStage' | 'isComplete'>) => {
    const newProduct: Product = {
      ...productData,
      id: uuidv4(),
      currentStage: ProductStages.HARVEST,
      isComplete: false
    };
    
    setProducts(prevProducts => [...prevProducts, newProduct]);
    
    // Create an initial block for this product
    addBlock({
      productId: newProduct.id,
      productName: newProduct.name,
      stage: ProductStages.HARVEST,
      location: `${newProduct.farmName}`,
      actor: `Farmer ID: ${newProduct.farmerId}`,
      details: {
        harvestDate: newProduct.harvestDate,
        quantity: `${newProduct.quantity} ${newProduct.unit}`,
        type: newProduct.type
      }
    });
    
    return newProduct;
  };

  const getProductById = (id: string) => {
    return products.find(product => product.id === id);
  };

  const getBlocksForProduct = (productId: string) => {
    return blockchain.getBlocksForProduct(productId);
  };

  const validateChain = () => {
    return blockchain.isChainValid();
  };

  const value = {
    blockchain,
    products,
    loading,
    addBlock,
    addProduct,
    getProductById,
    getBlocksForProduct,
    validateChain
  };

  return (
    <BlockchainContext.Provider value={value}>
      {children}
    </BlockchainContext.Provider>
  );
};