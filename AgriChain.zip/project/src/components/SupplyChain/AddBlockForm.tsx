import React, { useState } from 'react';
import { useBlockchain } from '../../context/BlockchainContext';
import { ProductStages } from '../../models/Product';

interface AddBlockFormProps {
  productId: string;
  currentStage: string;
  onSuccess: () => void;
}

const stageOptions = [
  { value: ProductStages.HARVEST, label: 'Harvest' },
  { value: ProductStages.PROCESSING, label: 'Processing' },
  { value: ProductStages.PACKAGING, label: 'Packaging' },
  { value: ProductStages.DISTRIBUTION, label: 'Distribution' },
  { value: ProductStages.RETAIL, label: 'Retail' },
  { value: ProductStages.CONSUMER, label: 'Consumer' }
];

const AddBlockForm: React.FC<AddBlockFormProps> = ({ 
  productId, 
  currentStage,
  onSuccess 
}) => {
  const { addBlock, getProductById } = useBlockchain();
  const product = getProductById(productId);
  
  const currentStageIndex = stageOptions.findIndex(
    option => option.value === currentStage
  );
  const nextStage = currentStageIndex < stageOptions.length - 1 
    ? stageOptions[currentStageIndex + 1].value 
    : null;
  
  const [formData, setFormData] = useState({
    stage: nextStage || '',
    location: '',
    actor: '',
    details: ''
  });
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  if (!product) {
    return <div>Product not found</div>;
  }
  
  if (!nextStage) {
    return (
      <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
        <p className="text-green-800">
          This product has completed its journey through the supply chain!
        </p>
      </div>
    );
  }
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    
    try {
      // Parse details as JSON
      let detailsObj = {};
      try {
        if (formData.details.trim()) {
          // Allow simplified format like "key: value, key2: value2"
          const detailsStr = formData.details
            .split(',')
            .map(item => {
              const [key, value] = item.split(':');
              return `"${key.trim()}":"${value.trim()}"`;
            })
            .join(',');
          
          detailsObj = JSON.parse(`{${detailsStr}}`);
        }
      } catch (err) {
        throw new Error('Details must be in format "key: value, key2: value2"');
      }
      
      addBlock({
        productId,
        productName: product.name,
        stage: formData.stage,
        location: formData.location,
        actor: formData.actor,
        details: detailsObj
      });
      
      onSuccess();
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('An unexpected error occurred');
      }
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h3 className="text-lg font-medium mb-4">Add New Supply Chain Stage</h3>
      
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Stage
          </label>
          <select
            name="stage"
            value={formData.stage}
            onChange={handleChange}
            required
            className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
          >
            <option value="">Select next stage</option>
            {stageOptions.slice(currentStageIndex + 1).map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
        
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Location
          </label>
          <input
            type="text"
            name="location"
            value={formData.location}
            onChange={handleChange}
            required
            placeholder="e.g., Processing Facility, CA"
            className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
          />
        </div>
        
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Actor/Person
          </label>
          <input
            type="text"
            name="actor"
            value={formData.actor}
            onChange={handleChange}
            required
            placeholder="e.g., Processing Team"
            className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
          />
        </div>
        
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Details (key: value, key2: value2)
          </label>
          <textarea
            name="details"
            value={formData.details}
            onChange={handleChange}
            placeholder="e.g., temperature: 25°C, humidity: 70%"
            className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
            rows={3}
          />
        </div>
        
        <button
          type="submit"
          disabled={loading}
          className="w-full bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-4 rounded-md transition-colors duration-300 disabled:bg-gray-400"
        >
          {loading ? 'Processing...' : 'Add Block'}
        </button>
      </form>
    </div>
  );
};

export default AddBlockForm;