import React from 'react';
import { Block } from '../../models/Block';
import { format } from 'date-fns';
import { 
  Wheat, 
  Package, 
  Box, 
  Truck, 
  ShoppingBag, 
  Home,
  Check
} from 'lucide-react';

interface SupplyChainTimelineProps {
  blocks: Block[];
}

const stageIcons = {
  genesis: <Home className="w-5 h-5 text-gray-500" />,
  harvest: <Wheat className="w-5 h-5 text-green-500" />,
  processing: <Package className="w-5 h-5 text-yellow-500" />,
  packaging: <Box className="w-5 h-5 text-blue-500" />,
  distribution: <Truck className="w-5 h-5 text-purple-500" />,
  retail: <ShoppingBag className="w-5 h-5 text-red-500" />,
  consumer: <Home className="w-5 h-5 text-teal-500" />
};

const stageTitles = {
  genesis: 'Genesis',
  harvest: 'Harvested',
  processing: 'Processing',
  packaging: 'Packaging',
  distribution: 'Distribution',
  retail: 'Retail',
  consumer: 'Consumer'
};

const SupplyChainTimeline: React.FC<SupplyChainTimelineProps> = ({ blocks }) => {
  // Filter out genesis block
  const productBlocks = blocks.filter(block => block.data.productId !== 'genesis');
  
  if (productBlocks.length === 0) {
    return <div className="text-center py-8">No supply chain data available</div>;
  }
  
  return (
    <div className="relative">
      <div className="absolute left-6 md:left-8 top-0 bottom-0 w-0.5 bg-green-200"></div>
      
      {productBlocks.map((block, index) => (
        <div 
          key={block.hash} 
          className="relative flex items-start mb-8 animate-fadeIn"
          style={{ animationDelay: `${index * 150}ms` }}
        >
          <div className="flex-shrink-0 w-12 h-12 md:w-16 md:h-16 rounded-full bg-white border-2 border-green-500 flex items-center justify-center z-10">
            {stageIcons[block.data.stage as keyof typeof stageIcons] || 
              <div className="w-6 h-6 rounded-full bg-gray-300 flex items-center justify-center">
                ?
              </div>}
          </div>
          
          <div className="ml-4 md:ml-6 bg-white rounded-lg shadow-md p-4 flex-grow">
            <div className="flex flex-col md:flex-row md:justify-between md:items-start mb-2">
              <h3 className="text-lg font-semibold">
                {stageTitles[block.data.stage as keyof typeof stageTitles]}
              </h3>
              <span className="text-sm text-gray-500">
                {format(new Date(block.data.timestamp), 'MMM dd, yyyy • h:mm a')}
              </span>
            </div>
            
            <div className="mb-3 grid grid-cols-1 md:grid-cols-2 gap-x-4">
              <p className="text-sm text-gray-600 mb-1">
                <strong>Location:</strong> {block.data.location}
              </p>
              <p className="text-sm text-gray-600 mb-1">
                <strong>Actor:</strong> {block.data.actor}
              </p>
            </div>
            
            {Object.keys(block.data.details).length > 0 && (
              <div className="border-t pt-2 mt-2">
                <h4 className="text-sm font-medium mb-1">Details:</h4>
                <div className="flex flex-wrap gap-2">
                  {Object.entries(block.data.details).map(([key, value]) => (
                    <span 
                      key={key} 
                      className="inline-block bg-gray-100 rounded-full px-3 py-1 text-xs"
                    >
                      {key}: {value}
                    </span>
                  ))}
                </div>
              </div>
            )}
            
            <div className="mt-3 pt-2 border-t border-dashed">
              <div className="flex items-center text-xs text-gray-400">
                <Check className="w-3 h-3 mr-1" />
                <span className="mr-1">Verified on blockchain:</span>
                <span className="font-mono">{block.hash.substring(0, 16)}...</span>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default SupplyChainTimeline;