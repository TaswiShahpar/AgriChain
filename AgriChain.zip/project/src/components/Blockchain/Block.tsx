import React from 'react';
import { Block as BlockModel } from '../../models/Block';
import { format } from 'date-fns';
import { Package, Truck, Box, ShoppingBag, Home, Wheat } from 'lucide-react';

interface BlockProps {
  block: BlockModel;
  isGenesis?: boolean;
}

const stageIcons = {
  genesis: <Home className="w-6 h-6 text-gray-500" />,
  harvest: <Wheat className="w-6 h-6 text-green-500" />,
  processing: <Package className="w-6 h-6 text-yellow-500" />,
  packaging: <Box className="w-6 h-6 text-blue-500" />,
  distribution: <Truck className="w-6 h-6 text-purple-500" />,
  retail: <ShoppingBag className="w-6 h-6 text-red-500" />,
  consumer: <Home className="w-6 h-6 text-teal-500" />
};

const BlockComponent: React.FC<BlockProps> = ({ block, isGenesis = false }) => {
  return (
    <div className={`border rounded-lg p-4 shadow-md transition-all duration-300 ${
      isGenesis ? 'bg-gray-100' : 'bg-white hover:shadow-lg'
    }`}>
      <div className="flex items-center mb-2">
        {stageIcons[block.data.stage as keyof typeof stageIcons] || 
          <div className="w-6 h-6 rounded-full bg-gray-300 flex items-center justify-center">
            ?
          </div>}
        <h3 className="text-lg font-semibold ml-2">
          {isGenesis ? 'Genesis Block' : block.data.stage.charAt(0).toUpperCase() + block.data.stage.slice(1)}
        </h3>
      </div>
      
      {!isGenesis && (
        <div className="mb-3">
          <p className="text-sm text-gray-500 mb-1">Product: {block.data.productName}</p>
          <p className="text-sm text-gray-500 mb-1">
            Date: {format(new Date(block.data.timestamp), 'MMM dd, yyyy')}
          </p>
          <p className="text-sm text-gray-500 mb-1">Location: {block.data.location}</p>
          <p className="text-sm text-gray-500">Actor: {block.data.actor}</p>
        </div>
      )}
      
      <div className="border-t pt-2 mt-2">
        <div className="flex flex-wrap gap-2">
          {!isGenesis && Object.entries(block.data.details).map(([key, value]) => (
            <span 
              key={key} 
              className="inline-block bg-gray-100 rounded-full px-3 py-1 text-xs"
            >
              {key}: {value}
            </span>
          ))}
        </div>
      </div>
      
      <div className="mt-3 pt-2 border-t border-dashed text-xs text-gray-400 overflow-hidden">
        <p className="truncate" title={block.hash}>Hash: {block.hash.substring(0, 15)}...</p>
        <p className="truncate" title={block.previousHash}>Prev: {block.previousHash.substring(0, 15)}...</p>
      </div>
    </div>
  );
};

export default BlockComponent;