import React from 'react';
import { Block as BlockModel } from '../../models/Block';
import BlockComponent from './Block';
import { ArrowRight } from 'lucide-react';

interface BlockchainViewerProps {
  blocks: BlockModel[];
}

const BlockchainViewer: React.FC<BlockchainViewerProps> = ({ blocks }) => {
  if (blocks.length === 0) {
    return <div className="text-center py-8">No blocks to display</div>;
  }

  return (
    <div className="w-full overflow-x-auto">
      <div className="inline-flex items-start gap-2 p-4 min-w-max">
        {blocks.map((block, index) => (
          <React.Fragment key={block.hash}>
            <BlockComponent 
              block={block} 
              isGenesis={index === 0 && block.data.productId === 'genesis'} 
            />
            {index < blocks.length - 1 && (
              <div className="flex items-center justify-center h-full pt-20">
                <ArrowRight className="w-6 h-6 text-gray-400" />
              </div>
            )}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
};

export default BlockchainViewer;