import React from 'react';
import { Link } from 'react-router-dom';
import { Product, ProductStages } from '../../models/Product';
import { 
  Wheat, 
  Package, 
  Box, 
  Truck, 
  ShoppingBag, 
  Home,
  CheckCircle
} from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

const stageIcons = {
  [ProductStages.HARVEST]: <Wheat className="w-5 h-5" />,
  [ProductStages.PROCESSING]: <Package className="w-5 h-5" />,
  [ProductStages.PACKAGING]: <Box className="w-5 h-5" />,
  [ProductStages.DISTRIBUTION]: <Truck className="w-5 h-5" />,
  [ProductStages.RETAIL]: <ShoppingBag className="w-5 h-5" />,
  [ProductStages.CONSUMER]: <Home className="w-5 h-5" />
};

const stageTitles = {
  [ProductStages.HARVEST]: 'Harvested',
  [ProductStages.PROCESSING]: 'Processing',
  [ProductStages.PACKAGING]: 'Packaging',
  [ProductStages.DISTRIBUTION]: 'In Distribution',
  [ProductStages.RETAIL]: 'At Retail',
  [ProductStages.CONSUMER]: 'With Consumer'
};

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const stageProgress = (() => {
    const stages = Object.values(ProductStages);
    const currentIndex = stages.indexOf(product.currentStage);
    return Math.round((currentIndex / (stages.length - 1)) * 100);
  })();
  
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:shadow-lg hover:-translate-y-1">
      <div className="relative h-48">
        <img 
          src={product.imageUrl || 'https://images.pexels.com/photos/5560867/pexels-photo-5560867.jpeg'} 
          alt={product.name}
          className="w-full h-full object-cover"
        />
        {product.isComplete && (
          <div className="absolute top-2 right-2 bg-green-100 text-green-800 rounded-full py-1 px-3 text-xs font-medium flex items-center">
            <CheckCircle className="w-3 h-3 mr-1" />
            Complete
          </div>
        )}
      </div>
      
      <div className="p-4">
        <h2 className="font-bold text-xl mb-1">{product.name}</h2>
        <p className="text-gray-600 text-sm mb-2">
          {product.type} • {product.quantity} {product.unit}
        </p>
        
        <div className="flex items-center text-sm text-gray-500 mb-3">
          <span className="mr-1">Farm:</span>
          <span className="font-medium">{product.farmName}</span>
        </div>
        
        <div className="mb-3">
          <div className="flex justify-between items-center mb-1">
            <div className="flex items-center">
              <span className="text-sm font-medium mr-2">Stage:</span>
              <span className="flex items-center text-sm bg-green-100 text-green-800 rounded-full py-1 px-2">
                {stageIcons[product.currentStage as keyof typeof stageIcons]}
                <span className="ml-1">{stageTitles[product.currentStage as keyof typeof stageTitles]}</span>
              </span>
            </div>
          </div>
          
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-green-600 h-2 rounded-full" 
              style={{ width: `${stageProgress}%` }}
            ></div>
          </div>
        </div>
        
        <Link 
          to={`/products/${product.id}`}
          className="block w-full text-center bg-green-600 hover:bg-green-700 text-white py-2 rounded-md transition-colors duration-300"
        >
          View Journey
        </Link>
      </div>
    </div>
  );
};

export default ProductCard;