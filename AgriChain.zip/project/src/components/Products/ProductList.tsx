import React from 'react';
import { useBlockchain } from '../../context/BlockchainContext';
import ProductCard from './ProductCard';
import { Loader, PlusCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

const ProductList: React.FC = () => {
  const { products, loading } = useBlockchain();
  
  if (loading) {
    return (
      <div className="flex justify-center items-center py-16">
        <Loader className="w-8 h-8 text-green-600 animate-spin" />
      </div>
    );
  }
  
  if (products.length === 0) {
    return (
      <div className="text-center py-16">
        <h2 className="text-2xl font-bold text-gray-700 mb-4">No Products Yet</h2>
        <p className="text-gray-500 mb-6">Start by adding your first agricultural product to track</p>
        <Link 
          to="/products/new"
          className="inline-flex items-center bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-md transition-colors duration-300"
        >
          <PlusCircle className="w-5 h-5 mr-2" />
          Add Product
        </Link>
      </div>
    );
  }
  
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Products ({products.length})</h2>
        <Link 
          to="/products/new"
          className="inline-flex items-center bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-md transition-colors duration-300"
        >
          <PlusCircle className="w-5 h-5 mr-2" />
          Add Product
        </Link>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map(product => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
};

export default ProductList;